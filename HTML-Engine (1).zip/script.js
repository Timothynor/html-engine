function setup(){
  createCanvas(1500,1000,WEBGL)
  background(150)
}
function draw(){
  beginShape()
  vertex(-200,0,0)
  vertex(-100,0,0)
  endShape(CLOSE)
}