var EntityExist;
var EntityCount;
var server;
module.exports = () => {
  var data = { Population: [] }
  for(let Epop = 0; Epop < EntityCount; Epop++){
    data.Population.push({ id: Epop, name: ‘Population${Epop}‘ })
  }
  if(EntityExist === true){
    return data
  }
}