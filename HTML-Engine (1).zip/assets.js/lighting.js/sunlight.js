const Sunradius = 695510
function setup(){
  createCanvas(1500,1000,WEBGL);
  background(225)
  directionalLight(248,186,124,1400,999),1
  translate(-1.5 * Sunradius, 0, 0);
}