let img;
function preload(){
  img = loadImage("https://www.google.com/search?q=wood+texture&safe=strict&rlz=1CACLSF_enCA840&tbm=isch&source=iu&ictx=1&fir=ke51T8CwJH8BbM%253A%252CQ-vbyaWgA1g_2M%252C_&vet=1&usg=AI4_-kTgcSfecMEQEpokbRI1-ezxPyOoFg&sa=X&ved=2ahUKEwjyh-_28oHhAhU1IDQIHXqdDgoQ9QEwAXoECAAQBg#imgrc=ke51T8CwJH8BbM:");
}
function setup(){
  createCanvas(1500,1000,WEBGL);
}
function draw(){
  background(255);
  texture(img);
  box(45);
}