var triangle = function setup(){
  beginShape();
  vertex(100,0,0)
  vertex(200,100,0)
  vertex(300,0,0)
  endShape(CLOSE);
}
