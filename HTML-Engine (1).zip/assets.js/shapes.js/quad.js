var quad = function setup(){
  beginShape();
  vertex(0,0,0)
  vertex(100,0,0)
  vertex(100,100,0)
  vertex(0,100)
  endShape(CLOSE);
}