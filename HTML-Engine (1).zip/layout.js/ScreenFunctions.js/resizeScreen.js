import Layout.js from './lib/Layout.js'
define('resizeScreen.js', function draw(RE_Button){
  RE_Button = createButton("resize")
  RE_Button.mousePressed(
    translate(-100,50)
    prompt("how big do you want the screen to be")
    screenSizeChanger = createSlider(600,4000,600)
    for(function draw(layout[0],layout[4],layout[8],layout[12]) < screenSizeChanger; )
    )
})