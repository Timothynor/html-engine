let resizeTrue = false;
require(['lib/Layout.js'], function draw(layout){
  console.log(layout);
})
require(['lib/resizeScreen.js'], function draw(resizeScreenLayout){
  if(resizeTrue === true){
    console.log(resizeScreenLayout);
  }
})