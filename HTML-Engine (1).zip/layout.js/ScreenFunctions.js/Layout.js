function setup(){
  createCanvas(1500,1000,WEBGL)
}
define('Layout.js', function draw(layout){
  var layout = [
    //first box
    point(-200,0,0),
    point(-300,0,0),
    point(-300,400,0),
    point(-200,400,0),
    
    //top box
    point(-200,0,0),
    point(400,0,0),
    point(400,50,0),
    point(-200,50,0),

    //left box
    point(400,0,0),
    point(500,0,0),
    point(500,400,0),
    point(400,400,0),

    //bottom box
    point(-200,350,0),
    point(-200,400,0),
    point(-400,400,0),
    point(-400,350,0)
    ]
  return layout
})